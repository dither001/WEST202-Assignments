/*
 * @author Nick Foster
 * @date October 2017
 * 
 * Modified from original code provided for assignment.
 */

/*
CLASS: AsteroidsGame
DESCRIPTION: Extending Game, Asteroids is all in the paint method.
NOTE: This class is the metaphorical "main method" of your program,
      it is your control center.
Original code by Dan Leyzberg and Art Simon
 */
import java.awt.*;
import java.util.ArrayList;

@SuppressWarnings("serial")
public class Asteroids extends Game {
	// fields
	public static final int SCREEN_WIDTH = 800;
	public static final int SCREEN_HEIGHT = 600;
	static int counter = 0;
	private int damageTimer = 0;
	
	Star[] stars;
	Asteroid[] roids;
	Ship ship;
	
	// constructors
	public Asteroids() {
		super("Asteroids!", SCREEN_WIDTH, SCREEN_HEIGHT);
		this.setFocusable(true);
		this.requestFocus();
		
		stars = new Star[300];
		for (int i = 0; i < stars.length; ++i) {
			stars[i] = new Star();
		}
		
		roids = new Asteroid[8];
		for (int i = 0; i < roids.length; ++i) {
			roids[i] = new Asteroid();
		}
		ship = new Ship();
		this.addKeyListener(ship);
	}
	
	// methods
	public void paint(Graphics brush) {
		brush.setColor(Color.black);
		brush.fillRect(0,0,width,height);
		
		// sample code for printing message for debugging
		// counter is incremented and this message printed
		// each time the canvas is repainted
		counter++;
		brush.setColor(Color.white);
		brush.drawString("Counter is " + counter,10,10);
		
		// paints each of the stars
		for (Star el : stars) {
			el.paint(brush, Color.GRAY);
			el.move();
		}
		
		// paints each of the asteroids
		for (Asteroid el : roids) {
			el.move();
			el.paint(brush, Color.WHITE);
			if (el.collision(ship) && damageTimer < 1) damageTimer = 100;
		}
		
		if ((ship.getBullets()).size() > 0) {
			ArrayList<Bullet> removeList = new ArrayList<Bullet>();
			// iterate through bullets; move & paint
			for (Bullet el : ship.getBullets()) {
				if (! (el.isOutOfBounds())) {
					el.move();
					el.paint(brush, Color.RED);
				} else {
					removeList.add(el);
				}
			}
			// remove bullets out-of-bounds
			for (Bullet el : removeList) {
				(ship.getBullets()).remove(el);
			}
		}
		
		if (damageTimer < 1) {
			ship.paint(brush, Color.RED);
		} else if (damageTimer % 2 == 0){
			ship.paint(brush, Color.WHITE);
			--damageTimer;
		} else if (damageTimer % 2 == 1){
			ship.paint(brush, Color.RED);
			--damageTimer;
		}
		
		ship.move();
	}
	
	// main method
	public static void main (String[] args) {
		Asteroids a = new Asteroids();
		a.repaint();
	}
}