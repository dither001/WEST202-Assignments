/*
 * @author Nick Foster
 * @date October 2017
 * 
 * Represents stars of varying depths.
 */

import java.awt.Color;
import java.awt.Graphics;

public class Star extends Circle {
	// fields
	private enum Distance {NEAR, MEDIUM, FAR}
	public double rotation;
	
	private Distance distance;
	private Point origin;
	
	// constructors
	public Star() {
		this(randomPosition(), (int) 3);
	}
		
	public Star(Point center, int radius) {
		super(center, radius);
		this.origin = center;
		rotation = Math.random() * 360;
		
		double n = Math.random();
		if (n < 0.8) distance = Distance.FAR;
		else if (n < 0.95) distance = Distance.MEDIUM;
		else distance = Distance.NEAR;
		
	}

	// methods
	@Override
	public void paint(Graphics brush, Color color) {
		if (distance == Distance.FAR) brush.setColor(Color.DARK_GRAY);
		else if (distance == Distance.MEDIUM) brush.setColor(Color.GRAY);
		else brush.setColor(Color.WHITE);
		
		brush.fillOval((int) (origin.x), (int) (origin.y), radius, radius);		
	}

	@Override
	public void move() {
		// TODO
	}
	
	private static Point randomPosition() {
		double x = Math.random() * Asteroids.SCREEN_WIDTH;
		double y = Math.random() * Asteroids.SCREEN_WIDTH;
		
		return new Point(x,y);
	}
}
