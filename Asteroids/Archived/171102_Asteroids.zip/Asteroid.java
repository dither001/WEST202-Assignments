/*
 * @author Nick Foster
 * @date October 2017
 * 
 * Represents asteroid object in "space."
 */

import java.awt.Color;
import java.awt.Graphics;

public class Asteroid extends Polygon {
	// Asteroid shape and size ranges
	private static final int MIN_SIDES =  8;
	private static final int MAX_SIDES = 12;
	private static final int MIN_SIZE  = 40;
	private static final int MAX_SIZE  = 80;
	
	// fields
	private Point[] shape;
//	private boolean isActive;
	private int spin;
	private int bounceCount;
	
	// constructors
	public Asteroid() {
		this(true);
	}
	
	public Asteroid(boolean isActive) {
		this(randomShape(), randomPosition(), Math.random() * 360, isActive);
	}
	
	public Asteroid(Point[] shape, Point position, double rotation, boolean isActive) {
		super(shape, position, rotation);
		this.shape = shape;
//		this.isActive = isActive;
		this.spin = randomSpin();
		this.bounceCount = 0;
	}
	
	@Override
	public void paint(Graphics brush, Color color) {
//		if (isActive) {
//			this.move();
//		}
		
		Point[] points = this.getPoints();
		Point currentPoint = null;
		int[] exes = new int[this.shape.length];
		int[] whys = new int[this.shape.length];
		
		for (int i = 0; i < this.shape.length; ++i) {
			currentPoint = points[i];
			exes[i] = (int)currentPoint.x;
			whys[i] = (int)currentPoint.y;
		}
		
		brush.setColor(color);
		brush.drawPolygon(exes, whys, this.shape.length);
//		brush.setColor(Color.GRAY);
//		brush.fillPolygon(exes, whys, this.shape.length);
	}

	@Override
	public void move() {
		//rotate(spin);
		
		position.x += 1.2 * Math.cos(Math.toRadians(rotation));
		position.y += 1.2 * Math.sin(Math.toRadians(rotation));
		
	    // wrap horizontal
	    if (position.x < -(Asteroids.SCREEN_WIDTH * 0.1)) {position.x = (Asteroids.SCREEN_WIDTH * 1.1);}
	    if (position.x > (Asteroids.SCREEN_WIDTH * 1.1)) {position.x = -(Asteroids.SCREEN_WIDTH * 0.1);}
	    
	    // wrap vertical
	    if (position.y < -(Asteroids.SCREEN_HEIGHT * 0.1)) {position.y = (Asteroids.SCREEN_HEIGHT * 1.1);}
	    if (position.y > (Asteroids.SCREEN_HEIGHT * 1.1)) {position.y = -(Asteroids.SCREEN_HEIGHT * 0.1);}
	}
	
	/*
	 * PRIVATE METHODS
	 */
	private static Point[] randomShape() {
		int sides, x, y;
		double size, theta;
		
		// randomly determines a whole number of sides between 8-12 
		sides = MIN_SIDES + (int) (Math.random() * (MAX_SIDES - MIN_SIDES));
		Point[] shape = new Point[sides];
		
		for (int i = 0; i < sides; ++i) {
	        theta = 2 * Math.PI / sides * i;
	        size = MIN_SIZE + (int) (Math.random() * (MAX_SIZE - MIN_SIZE));
	        x = (int) -Math.round(size * Math.sin(theta));
	        y = (int)  Math.round(size * Math.cos(theta));
	        shape[i] = new Point(x, y);
		}
		
		return shape;
	}
	
	private static Point randomPosition() {
		int x, y;
		
		// randomly determines x, y somewhere within visible screen
		if (Math.random() < 0.5) {
			if (Math.random() < 0.5) {
				x = (int) (Asteroids.SCREEN_WIDTH * 0.1);
			} else {
				x = (int) (Asteroids.SCREEN_WIDTH * 0.9);
			}
			y = (int) (Math.random() * Asteroids.SCREEN_HEIGHT);
		} else {
			x = (int) (Math.random() * Asteroids.SCREEN_WIDTH);
			if (Math.random() < 0.5) {
				y = (int) (Asteroids.SCREEN_HEIGHT * 0.1);
			} else {
				y = (int) (Asteroids.SCREEN_HEIGHT * 0.9);
			}
		}
		
		return new Point(x, y);
	}
	
	private static int randomSpin() {
		double spin = Math.random();
		
		if (spin < 0.2) spin = -1.0;
		else if (spin < 0.4) spin = 1.0;
		else spin = 0.0;
		
		return (int) spin;
	}
}
